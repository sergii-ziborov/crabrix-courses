pub fn solve(input: &str) -> String {
    // Return the number of solutions for a 5x5 board.
    // Parse the visible input into the structures your algorithm needs.
    // Whitespace surrounding the complete input is insignificant.
    let _ = input;
    todo!("implement N-Queens")
}